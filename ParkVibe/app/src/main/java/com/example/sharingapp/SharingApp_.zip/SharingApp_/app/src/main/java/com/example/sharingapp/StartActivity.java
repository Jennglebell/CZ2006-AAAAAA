package com.example.sharingapp;

class StartActivity {
}
